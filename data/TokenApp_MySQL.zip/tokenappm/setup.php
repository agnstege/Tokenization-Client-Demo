<?php
function write_auth_file($db_host, $db_username, $db_password, $db_name, $tokenserver, $TokenUser_Customer, $TokenUser_Customer_pwd)
        {
                $myfile = fopen("auth.php", "w") or die("Unable to open file!");
                $txt = "<?php\n\n\$db_host = \"$db_host\";\n\$db_username = \"$db_username\";\n\$db_password = \"$db_password\";\n\$db_name = \"$db_name\";\n\$tokenserver = \"$tokenserver\";\n\$TokenUser_Customer = \"$TokenUser_Customer\";\n\$TokenUser_Customer_pwd = \"$TokenUser_Customer_pwd\";\n?>";
                fwrite($myfile, $txt);
                fclose($myfile);
                $myfile = fopen("auth.php", "r") or die("Unable to open file!");
                return fread($myfile,filesize("auth.php"));
                fclose($myfile);

        }
?>
<html>
<head>
    <meta http-equiv='Content-Type' content='text/html; charset=utf-8'/>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Setup Environment</title>
    <link rel="STYLESHEET" type="text/css" href="style/main.css">
</head>
<body>

  <div class="imgcontainer">
    <img src="images/Thales-logo.png" class="logo">
  </div>

<?php
if (!isset($_POST['tip'])) {
        echo "<form action=\"\" method=\"post\">";
        echo "<div class=\"col-50\">";
        echo "<p><span><b>Tokenserver IP Address</b></span><input class=\"contact\" type=\"text\" name=\"tip\" value=\"\" /></p>";
        echo "<p><span><b>Tokenserver User Name</b></span><input class=\"contact\" type=\"text\" name=\"tuser\" value=\"\" /></p>";
        echo "<p><span><b>Tokenserver Password</b></span><input class=\"contact\" type=\"text\" name=\"tpass\" value=\"\" /></p>";
        echo "<p><span><b>Database IP</b></span><input class=\"contact\" type=\"text\" name=\"dbip\" value=\"\" /></p>";
        echo "<p><span><b>Database Name</b></span><input class=\"contact\" type=\"text\" name=\"dbname\" value=\"\" /></p>";
        echo "<p><span><b>DB User</b></span><input class=\"contact\" type=\"text\" name=\"dbuser\" value=\"\" /></p>";
        echo "<p><span><b>DB User Password Password</b></span><input class=\"contact\" type=\"text\" name=\"dbpass\" value=\"\" /></p>";
        echo "<p style=\"padding-top: 15px\"><span>&nbsp;</span><input class=\"submit\" type=\"submit\" name=\"Connect\" value=\"Save Settings to File\" /></p>";
        echo "</div>";
        echo "</form>";

        } elseif (isset($_POST['tip'])) {
                $tokenserver = $_POST['tip'];
                $TokenUser_Customer = $_POST['tuser'];
                $TokenUser_Customer_pwd = $_POST['tpass'];
                $db_host = $_POST['dbip'];
                $db_name = $_POST['dbname'];
                $db_username = $_POST['dbuser'];
                $db_password = $_POST['dbpass'];
               $feedback = write_auth_file($db_host, $db_username, $db_password, $db_name, $tokenserver, $TokenUser_Customer, $TokenUser_Customer_pwd);
               if ($feedback == "") {
                       echo "<p>Failed to write to file</p>";
               }else {
                       echo "<p>Successfully wrote file auth.php</p>";
                       echo "<p><a href=\"index.html\">Start using application</a> <span class=\"price\"></span></p>";
                       echo $feedback;
               }
        }
?>

</body>
</html>

