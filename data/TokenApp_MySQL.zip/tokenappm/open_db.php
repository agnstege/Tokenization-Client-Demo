<?php
include "config.php";

$user=$_POST['uname'];
$pwd=$_POST['pwd'];


function detokenize ($token, $TokenTemplate)
{

include "config.php";

global $user;
global $pwd;

$command="curl -tlsv1.2 -k -X POST -u $user:$pwd -d '{\"tokengroup\" : \"$TokenGroup\" , \"token\" : \"$token\", \"tokentemplate\" : \"$TokenTemplate\" }' $detokurl";
$output = shell_exec($command);
$obj = json_decode($output);
$data = $obj->{"data"};

return $data;

}
?>


<html>
<head>
		  <meta http-equiv='Content-Type' content='text/html; charset=utf-8'/>
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <title>CTS Demo Back-Office</title>
      <link rel="STYLESHEET" type="text/css" href="style/main.css">
</head>

<body>
<img src="images/Thales-logo.png" class="logo">
<H2 align=center>Data view for <?php echo $user;?></H2>
<table>


  <thead>
  <tr>
    <th>Full Name</th>
    <th>Email</th> 
    <th>Address</th>
    <th>City</th>
    <th>County</th>
    <th>Postcode</th>
    <th>Name on Card</th>
    <th>Credit Card Number</th>
    <th>Expiration Date</th>
    <th>CVV</th>
  </tr>
  </thead>
  
  <tbody>
  
  <?php
 
  $conn = mysqli_connect($db_host, $db_username, $db_password, $db_name);
  if (!$conn) {
  	die ('Failed to connect to MySQL: ' . mysqli_connect_error());	
  }

  $conn = mysqli_connect($db_host, $db_username, $db_password, $db_name);
  if (!$conn) {
  	die ('Failed to connect to MySQL: ' . mysqli_connect_error());	
  }
  
  $sql = "SELECT * FROM $db_table";
  $result = mysqli_query($conn, $sql);
  
     
  while ($row = mysqli_fetch_array($result))
		{
        echo '<tr><td>'.$row[fname].'</td>      
              <td>'.detokenize($row[email], $Temp_FPE_Alpha).'</td>
              <td>'.$row[address].'</td>
              <td>'.$row[city].'</td>
              <td>'.$row[state].'</td>
              <td>'.$row[zip].'</td>
              <td>'.detokenize($row[cardname], $Temp_FPE_Alpha).'</td>
              <td>'.detokenize($row[cardnumber], $Temp_Random).'</td>
              <td>'.detokenize($row[expdate], $Temp_Date).'</td>
              <td>'.detokenize($row[cvv], $Temp_FPE_Digits).'</td></tr>';
               	
		}
  

  mysqli_close($conn);		
  
  ?>
  </tbody>   
  
</table> 

<form action="backoffice.html">
    <button type="Submit" class="btn-login">Back</button>
</form/

</body>
</html>
