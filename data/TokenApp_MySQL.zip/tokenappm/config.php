 <?php
include 'auth.php';

GLOBAL $db_host;
GLOBAL $db_username;
GLOBAL $db_password;
GLOBAL $db_name;
GLOBAL $tokenserver;
GLOBAL $TokenUser_Customer;
GLOBAL $TokenUser_Customer_pwd;

$db_table = "registered_users";
$TokenGroup = "ctsdemo_group";
$Temp_FPE_Digits = "Template_FPE_Digits";
$Temp_FPE_Alpha ="Template_FPE_Alphanumeric";
$Temp_Random = "Template_Random";
$Temp_Date = "Template_MMYY";

$tokurl="https://$tokenserver/vts/rest/v2.0/tokenize/";
$detokurl="https://$tokenserver/vts/rest/v2.0/detokenize/";

?> 
