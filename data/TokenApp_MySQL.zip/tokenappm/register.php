<?php
require_once("config.php");


//Function to tokenize a field
function tokenize ($data,$Temp)
{
include("config.php");
$command="curl -tlsv1.2 -k -X POST -u $TokenUser_Customer:$TokenUser_Customer_pwd -d '{\"tokengroup\" : \"$TokenGroup\" , \"data\" : \"$data\", \"tokentemplate\" : \"$Temp\" }' $tokurl";

$output = shell_exec($command);
$obj = json_decode($output);
$DataTokenized = $obj->{"token"};
return $DataTokenized;
}


if ($_SERVER["REQUEST_METHOD"] == "POST") {//Check it is comming from a form
    $fullname_init = $fullname = $_POST['fullname'];
    $email_init = $email = $_POST['email'];
    $address_init = $address = $_POST['address'];
    $city_init = $city = $_POST['city'];
    $state_init = $state = $_POST['state']; 
    $zip_init = $zip = $_POST['zip'];
    $cardname_init = $cardname = $_POST['cardname'];
    $cardnumber_init = $cardnumber = $_POST['cardnumber'];
    $expdate_init = $expdate = $_POST['expdate'];
    $cvv_init = $cvv = $_POST['cvv'];
    
    //toknenization of the fields
    
    //$fullname = tokenize ($fullname_init, $Temp_FPE_Alpha);
    $email = tokenize ($email_init, $Temp_FPE_Alpha);
    //$zip = tokenize ($zip_init, $Temp_FPE_Alpha);
    $cardname = tokenize ($cardname_init, $Temp_FPE_Alpha);
    $cardnumber = tokenize ($cardnumber_init, $Temp_Random);
    $expdate = tokenize ($expdate_init, $Temp_Date);
    $cvv = tokenize ($cvv_init, $Temp_FPE_Digits); 
    
    
    //Open a new connection to the MySQL server
    $mysqli = new mysqli($db_host, $db_username, $db_password, $db_name);
    
    //Output any connection error
    if ($mysqli->connect_error) {
        die('Error : ('. $mysqli->connect_errno .') '. $mysqli->connect_error);
    }   
    
    $statement = $mysqli->prepare("INSERT INTO $db_table (fname, email, address, city, state, zip, cardname, cardnumber, expdate, cvv) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"); //prepare sql insert query
    //bind parameters for markers, where (s = string, i = integer, d = double,  b = blob)
    $statement->bind_param('ssssssssss', $fullname, $email, $address, $city, $state, $zip, $cardname, $cardnumber, $expdate, $cvv); //bind values and execute insert query
    
    if($statement->execute()){
      
      include "data_registered.php";
                      
    }else{
        print $mysqli->error; //show mysql error if any
    }
    
}

?> 
