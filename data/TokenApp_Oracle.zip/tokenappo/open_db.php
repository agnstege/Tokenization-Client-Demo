<?php
include "config.php";

$user=$_POST['uname'];
$pwd=$_POST['pwd'];


function detokenize ($token, $TokenTemplate)
{

include "config.php";

global $user;
global $pwd;

$command="curl -tlsv1.2 -k -X POST -u $user:$pwd -d '{\"tokengroup\" : \"$TokenGroup\" , \"token\" : \"$token\", \"tokentemplate\" : \"$TokenTemplate\" }' $detokurl";
$output = shell_exec($command);
$obj = json_decode($output);
$data = $obj->{"data"};

return $data;

}
?>


<html>
<head>
		  <meta http-equiv='Content-Type' content='text/html; charset=utf-8'/>
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <title>CTS Demo Back-Office</title>
      <link rel="STYLESHEET" type="text/css" href="style/main.css">
</head>

<body>
<img src="images/Thales-logo.png" class="logo">
<H2 align=center>Data view for <?php echo $user;?></H2>
<table>


  <thead>
  <tr>
    <th>Full Name</th>
    <th>Email</th> 
    <th>Address</th>
    <th>City</th>
    <th>County</th>
    <th>Postcode</th>
    <th>Name on Card</th>
    <th>Credit Card Number</th>
    <th>Expiration Date</th>
    <th>CVV</th>
  </tr>
  </thead>
  
  <tbody>
  
  <?php
  
  //// Oracle Section

  $conn = oci_connect($db_username, $db_password, $db_host .'/'. $db_name);
  if (!$conn) {
                   $e = oci_error();
                   trigger_error(htmlentities($e['message'], ENT_QUOTES), E_USER_ERROR);
              }  

  $stid = oci_parse($conn, "SELECT * FROM $db_table");
if (!$stid) {
    $e = oci_error($conn);
    trigger_error(htmlentities($e['message'], ENT_QUOTES), E_USER_ERROR);
}

// Perform the logic of the query
$r = oci_execute($stid);
if (!$r) {
    $e = oci_error($stid);
    trigger_error(htmlentities($e['message'], ENT_QUOTES), E_USER_ERROR);
}
while ($row = oci_fetch_array($stid, OCI_ASSOC+OCI_RETURN_NULLS))
	 {
        echo '<tr><td>'.$row['FNAME'].'</td>
              <td>'.detokenize($row['EMAIL'], $Temp_FPE_Alpha).'</td>
              <td>'.$row['ADDRESS'].'</td>
              <td>'.$row['CITY'].'</td>
              <td>'.$row['STATE'].'</td>
              <td>'.$row['ZIP'].'</td>
              <td>'.detokenize($row['CARDNAME'], $Temp_FPE_Alpha).'</td>
              <td>'.detokenize($row['CARDNUMBER'], $Temp_Random).'</td>
              <td>'.detokenize($row['EXPDATE'], $Temp_Date).'</td>
              <td>'.detokenize($row['CVV'], $Temp_FPE_Digits).'</td></tr>';

                }
oci_free_statement($stid);
oci_close($conn);
//// End of Oracle Section
  ?>
  </tbody>   
  
</table> 

<form action="backoffice.html">
    <button type="Submit" class="btn-login">Back</button>
</form/

</body>
</html>
