<?php
include "config.php";

//// Oracle Section
$conn = oci_connect($db_username, $db_password, $db_host .'/'. $db_name);
    if (!$conn) {
                        $e = oci_error();
                        trigger_error(htmlentities($e['message'], ENT_QUOTES), E_USER_ERROR);
                }
$sql_query = "SELECT * FROM $db_table WHERE ID=(SELECT MAX(ID) FROM $db_table)";
$stid = oci_parse($conn, $sql_query);
//$stid = oci_parse($conn, "SELECT * FROM $db_table WHERE ID=(SELECT MAX(ID) FROM $db_table)");
if (!$stid) {
    $e = oci_error($conn);
    trigger_error(htmlentities($e['message'], ENT_QUOTES), E_USER_ERROR);
}
//// End of Oracle Section
?>


<html>
<head>
		  <meta http-equiv='Content-Type' content='text/html; charset=utf-8'/>
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <title>CTS Demo Website</title>
      <link rel="STYLESHEET" type="text/css" href="style/main.css">
</head>

<body>
<img src="images/Thales-logo.png" class="logo">
<H2 align=center>Data sent</H2>
<table>
  <thead>
  <tr>
    <th>Full Name</th>
    <th>Email</th> 
    <th>Address</th>
    <th>City</th>
    <th>State</th>
    <th>Zip</th>
    <th>Name on Card</th>
    <th>Credit Card Number</th>
    <th>Expiration Date</th>
    <th>CVV</th>
  </tr>
  </thead>
  
  <tbody>
    <tr>
  		<td><?php echo $fullname_init?></td>
      <td><?php echo $email_init?></td>
      <td><?php echo $address_init?></td>
      <td><?php echo $city_init?></td>
      <td><?php echo $state_init?></td>
      <td><?php echo $zip_init?></td>
      <td><?php echo $cardname_init?></td>
      <td><?php echo $cardnumber_init?></td>
      <td><?php echo $expdate_init?></td>
      <td><?php echo $cvv_init?></td>  
    </tr>                   
  </tbody>  
</table>
<br/>
<br/>
<br/>
<H2 align=center>Data stored</H2>
<table>
  <thead>
  <tr>
    <th>Full Name</th>
    <th>Email</th> 
    <th>Address</th>
    <th>City</th>
    <th>State</th>
    <th>Zip</th>
    <th>Name on Card</th>
    <th>Credit Card Number</th>
    <th>Expiration Date</th>
    <th>CVV</th>
  </tr>
  </thead>
    
  <tbody>
    <?php
    //$row = mysqli_fetch_array($query);
$r = oci_execute($stid);
if (!$r) {
    $e = oci_error($stid);
    trigger_error(htmlentities($e['message'], ENT_QUOTES), E_USER_ERROR);
}

    $row = oci_fetch_array($stid, OCI_ASSOC+OCI_RETURN_NULLS);
    echo '<tr>
					<td>'.$row['FNAME'].'</td>
					<td>'.$row['EMAIL'].'</td>
					<td>'.$row['ADDRESS'].'</td>
          <td>'.$row['CITY'].'</td>
          <td>'.$row['STATE'].'</td>
          <td>'.$row['ZIP'].'</td>
          <td>'.$row['CARDNAME'].'</td>
          <td>'.$row['CARDNUMBER'].'</td>
          <td>'.$row['EXPDATE'].'</td>
          <td>'.$row['CVV'].'</td>
				</tr>';
		
oci_free_statement($stid);
oci_close($conn);
    ?>  
  </tbody>  
</table>  

</body>
</html>
