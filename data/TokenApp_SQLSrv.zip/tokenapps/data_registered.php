<?php
include "config.php";

$connectionOptions = array(
    "database" => $db_name,
    "uid" => $db_username,
    "pwd" => $db_password,
    "encrypt" => 0,
    "TrustServerCertificate" => 1
);

//function exception_handler($exception) {
//    echo "<h1>Failure</h1>";
//    echo "Uncaught exception: " , $exception->getMessage();
//    echo "<h1>PHP Info for troubleshooting</h1>";
//    phpinfo();
//}

set_exception_handler('exception_handler');

// Establishes the connection
$conn = sqlsrv_connect($db_host, $connectionOptions);
if ($conn === false) {
    die(formatErrors(sqlsrv_errors()));
}

$sql = "SELECT * FROM $db_table WHERE ID=(SELECT MAX(ID) FROM $db_table)";
		
$query = sqlsrv_query($conn, $sql);

if (!$query) {
	die(print_r(sqlsrv_errors(), true));
}
?>


<html>
<head>
		  <meta http-equiv='Content-Type' content='text/html; charset=utf-8'/>
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <title>CTS Demo Website</title>
      <link rel="STYLESHEET" type="text/css" href="style/main.css">
</head>

<body>
<img src="images/Thales-logo.png" class="logo">
<H2 align=center>Data sent</H2>
<table>
  <thead>
  <tr>
    <th>Full Name</th>
    <th>Email</th> 
    <th>Address</th>
    <th>City</th>
    <th>State</th>
    <th>Zip</th>
    <th>Name on Card</th>
    <th>Credit Card Number</th>
    <th>Expiration Date</th>
    <th>CVV</th>
  </tr>
  </thead>
  
  <tbody>
    <tr>
  		<td><?php echo $fullname_init?></td>
      <td><?php echo $email_init?></td>
      <td><?php echo $address_init?></td>
      <td><?php echo $city_init?></td>
      <td><?php echo $state_init?></td>
      <td><?php echo $zip_init?></td>
      <td><?php echo $cardname_init?></td>
      <td><?php echo $cardnumber_init?></td>
      <td><?php echo $expdate_init?></td>
      <td><?php echo $cvv_init?></td>  
    </tr>                   
  </tbody>  
</table>
<br/>
<br/>
<br/>
<H2 align=center>Data stored</H2>
<table>
  <thead>
  <tr>
    <th>Full Name</th>
    <th>Email</th> 
    <th>Address</th>
    <th>City</th>
    <th>State</th>
    <th>Zip</th>
    <th>Name on Card</th>
    <th>Credit Card Number</th>
    <th>Expiration Date</th>
    <th>CVV</th>
  </tr>
  </thead>
    
  <tbody>
    <?php
    $row = sqlsrv_fetch_array($query);
    echo '<tr>
					<td>'.$row['fname'].'</td>
					<td>'.$row['email'].'</td>
					<td>'.$row['address'].'</td>
          <td>'.$row['city'].'</td>
          <td>'.$row['state'].'</td>
          <td>'.$row['zip'].'</td>
          <td>'.$row['cardname'].'</td>
          <td>'.$row['cardnumber'].'</td>
          <td>'.$row['expdate'].'</td>
          <td>'.$row['cvv'].'</td>
				</tr>';
		
    ?>  
  </tbody>  
</table>  

</body>
</html>
