<?php
require_once("config.php");


//Function to tokenize a field
function tokenize ($data,$Temp)
{
include("config.php");
$command="curl -tlsv1.2 -k -X POST -u $TokenUser_Customer:$TokenUser_Customer_pwd -d '{\"tokengroup\" : \"$TokenGroup\" , \"data\" : \"$data\", \"tokentemplate\" : \"$Temp\" }' $tokurl";

$output = shell_exec($command);
$obj = json_decode($output);
$DataTokenized = $obj->{"token"};
return $DataTokenized;
}


if ($_SERVER["REQUEST_METHOD"] == "POST") {//Check it is comming from a form
    $fullname_init = $fullname = $_POST['fullname'];
    $email_init = $email = $_POST['email'];
    $address_init = $address = $_POST['address'];
    $city_init = $city = $_POST['city'];
    $state_init = $state = $_POST['state']; 
    $zip_init = $zip = $_POST['zip'];
    $cardname_init = $cardname = $_POST['cardname'];
    $cardnumber_init = $cardnumber = $_POST['cardnumber'];
    $expdate_init = $expdate = $_POST['expdate'];
    $cvv_init = $cvv = $_POST['cvv'];
    
    //toknenization of the fields
    
    //$fullname = tokenize ($fullname_init, $Temp_FPE_Alpha);
    $email = tokenize ($email_init, $Temp_FPE_Alpha);
    //$zip = tokenize ($zip_init, $Temp_FPE_Alpha);
    $cardname = tokenize ($cardname_init, $Temp_FPE_Alpha);
    $cardnumber = tokenize ($cardnumber_init, $Temp_Random);
    $expdate = tokenize ($expdate_init, $Temp_Date);
    $cvv = tokenize ($cvv_init, $Temp_FPE_Digits); 
    
    
    //Open a new connection to the SQL server

$connectionOptions = array(
    "database" => $db_name,
    "UID" => $db_username,
    "PWD" => $db_password,
    "encrypt" => 0,
    "TrustServerCertificate" => 1
);

function exception_handler($exception) {
    echo "<h1>Failure</h1>";
    echo "Uncaught exception: " , $exception->getMessage();
    echo "<h1>PHP Info for troubleshooting</h1>";
    phpinfo();
}

set_exception_handler('exception_handler');

// Establishes the connection
$conn = sqlsrv_connect($db_host, $connectionOptions);
if ($conn === false) {
    die(formatErrors(sqlsrv_errors()));
}    

    
    $params = array(&$fullname, &$email, &$address, &$city, &$state, &$zip, &$cardname, &$cardnumber, &$expdate, &$cvv); //bind values and execute insert query

    $tsql = "INSERT INTO $db_table (fname, email, address, city, state, zip, cardname, cardnumber, expdate, cvv) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"; //prepare sql insert query
    
    $stmt = sqlsrv_prepare($conn, $tsql, $params);

    if(sqlsrv_execute($stmt)){
      
      	include "data_registered.php";
                      
    }else{
	echo "Statement could not be executed.\n";  
    	die(print_r(sqlsrv_errors(), true));
    }
sqlsrv_free_stmt($stmt);  
sqlsrv_close($conn);
    
}

?> 
